create function auditoria_prioridade_tr() returns trigger
    language plpgsql
as
$$
BEGIN

        if (OLD.prioridade <> NEW.prioridade) 
        THEN
            INSERT INTO auditoria_prioridade SELECT NEW.siape, now(), NEW.codigo_disc, OLD.prioridade, NEW.prioridade;
        END IF   ;
          
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;

alter function auditoria_prioridade_tr() owner to postgres;

