create function auditoria_fila_tr() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (TG_OP = 'DELETE') THEN
            INSERT INTO auditoria_fila SELECT OLD.*,'D', now();
            RETURN OLD;
        ELSIF (TG_OP = 'INSERT') THEN
            INSERT INTO auditoria_fila SELECT NEW.*,'I', now() ;
            RETURN NEW;
        ELSIF (TG_OP = 'UPDATE') THEN
            IF (NEW.STATUS = 13) THEN
               INSERT INTO auditoria_fila SELECT NEW.*,'R', now() ;
               RETURN NEW;
            END IF;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger

    END;
$$;

alter function auditoria_fila_tr() owner to postgres;

