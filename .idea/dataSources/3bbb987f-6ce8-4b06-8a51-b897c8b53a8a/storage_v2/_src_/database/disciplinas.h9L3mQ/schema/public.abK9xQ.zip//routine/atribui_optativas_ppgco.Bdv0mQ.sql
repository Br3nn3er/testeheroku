create function atribui_optativas_ppgco() returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 

-- fazer backup da função antiga renomeando-a

-- DISCIPLINAS ANUAIS


-- PROFESSORES CONSELHEIROS
-- "2615901 ";"5";"g"
-- "2615901 ";"5";"h"
-- "2615901 ";"5";"i"
-- "2615901 ";"5";"j"
-- "2615901 ";"5";"k"


-- disciplinas optativas
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('410840',93); -- COMP. MOVEL
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('1123423',94);  -- pdi
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('2035206',95); -- bioinfo

-- inserindo PPGCO
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('413877',88); -- análise
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('1999517',89); -- mineracao
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('1466361',90); -- bioinspirada
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('2250578',91); -- petri
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('2364418',92); -- redes por sw

-- voluntários

-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('413877',28); -- Márcia: CCO
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('413877',23); -- Márcia: TG


-- UPDATE fila_turma
-- SET status = 8
-- WHERE id_turma IN (SELECT id_turma FROM ministra);


---- 2017 01 -----
-- PATOS
-- Laurence
INSERT INTO MINISTRA(siape,id_turma) VALUES ('1625662', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBT518' AND ANO = 2017 AND SEMESTRE = 1)); --
INSERT INTO MINISTRA(siape,id_turma) VALUES ('1625662',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GAL007' AND ANO = 2017 AND SEMESTRE = 1) );  --
INSERT INTO MINISTRA(siape,id_turma) VALUES ('1625662',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE504' AND ANO = 2017 AND SEMESTRE = 1) );  --
  --GBT518 - Informática para Biotecnologia, 4 horas/semanais, Biotecnologia
  --GAL007 - Programação Computacional para Engenharia, 4 horas/semanais, Engenharia de Alimentos
  --GEE504 - Introdução à Tecnologia da Computação, 6 horas/semanais, Engenharia Eletrônica e de Telecomunicações

-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('1625662', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBT518' AND ANO = 2016 AND SEMESTRE = 2)); --
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('1625662',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE504' AND ANO = 2016 AND SEMESTRE = 2) );  --
  -- GBT518 Informática para Biotecnologia
  -- GEE504 Introdução à Tecnologia da Computação 
    
-- Eliana
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2152007', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE508' AND ANO = 2017 AND SEMESTRE = 1)); -- 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2152007',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE514' AND ANO = 2017 AND SEMESTRE = 1) );  --
 --GEE508 - Métodos e Técnicas de Programação, 6 horas/semanais, Engenharia Eletrônica e de Telecomunicações
 --GEE514 - Engenharia de Software, 4 horas/semanais, Engenharia Eletrônica e de Telecomunicações


--INSERT INTO MINISTRA(siape,id_turma) VALUES ('2152007',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE514' AND ANO = 2016 AND SEMESTRE = 2) );  --
--INSERT INTO MINISTRA(siape,id_turma) VALUES ('2152007',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GEE508' AND ANO = 2016 AND SEMESTRE = 2) );  --
 --INSERT INTO MINISTRA(siape,id_turma) VALUES ('2152007',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GAL007' AND ANO = 2016 AND SEMESTRE = 2) );  --

--Engenharia de Software (GEE514) - 2 teóricas, 2 práticas 
--Métodos e Técnicas de Programação (GEE508) 2 teóricas, 4 práticas
--Programação Computacional para Engenharia (GAL007) 2 teóricas, 2 práticas

-- disciplinas optativas
--BCC
INSERT INTO MINISTRA(siape,id_turma) VALUES ('410840', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC205' AND ANO = 2017 AND SEMESTRE = 1)); -- COMP. MOVEL - BACALÁ
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ('2143773',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC218' AND TURMA = 'CA' AND ANO = 2017 AND SEMESTRE = 1) );  -- Programação Paralela RENATO
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Lasaro'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC218' AND TURMA = 'CB' AND ANO = 2017 AND SEMESTRE = 1) );  -- Programação Paralela LÁSARO



-- BSI
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Keese'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI055'  AND ANO = 2017 AND SEMESTRE = 1) );  -- mineração
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'JoaoHenrique'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI064'  AND ANO = 2017 AND SEMESTRE = 1) );  -- resolucao problemas

  
  
-- BSI-MC
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Murillo'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI551' AND ANO = 2017 AND SEMESTRE = 1));  -- murillo IA
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Jefferson'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM39002' AND ANO = 2017 AND SEMESTRE = 1)); -- jefferson robotica


-- inserindo PPGCO

INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'LGustavo'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC102' AND ANO = 2017 AND SEMESTRE = 1)); --PGC102 - Lógica para Ciência da Computação 
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Marcia'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC101' AND ANO = 2017 AND SEMESTRE = 1)); --PGC101 - Análise de Algoritmos - Márcia Aparecida Fernandes
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Frosi'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC105' AND ANO = 2017 AND SEMESTRE = 1)); --PGC105 - Organização e Arquitetura de Computadores  - pedro
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Rivalino'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC303C' AND ANO = 2017 AND SEMESTRE = 1)); --PGC002B - Tóp. Esp. em Engenharia de Software 1 – Engenharia de Confiabilidade de Software  - Rivalino Matias Júnior
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Marcia'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC004C' AND ANO = 2017 AND SEMESTRE = 1)); -- Seminários em Computação 3 – Inteligência Artificial- Márcia
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'JGustavo'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC301A' AND ANO = 2017 AND SEMESTRE = 1)); --Visualização Computacional - Zé Gustavo
INSERT INTO MINISTRA(siape,id_turma) 
  VALUES ((SELECT siape FROM professor WHERE cnome = 'Fabiano'),(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'PGC305B' AND ANO = 2017 AND SEMESTRE = 1)); -- Tóp. Esp. em Inteligência Artificial 1 – Ontologias - Fabiano


  
-- voluntários
-- verificar se já não arrumou nas próprias filas

-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('413877',28); -- Márcia: CCO
-- INSERT INTO MINISTRA(siape,id_turma) VALUES ('413877',23); -- Márcia: TG


-- PROFESSORES AFASTADOS
/*
UPDATE PROFESSOR
SET afastado = true
WHERE SIAPE IN (
  '1881747',-- ";"Rafael Pasquini";"2011-08-04";"1988-02-04";TRUE;"de";0;"udi"
'3191429',-- ";"Ronaldo Castro de Oliveira";"2008-10-01";"1988-01-22";TRUE;"de";0;"udi"
'1690760',-- ";"Paulo Rodolfo da Silva Leite Coelho";"2009-03-17";"1988-01-26";TRUE;"de";0;"udi"
'1974399',-- ";"Mirella Silva Junqueira";"2012-10-07";"1982-02-03";FALSE;"de";12;"mc"
'2083950',-- ";"Murillo Guimarães Carneiro";"2014-01-28";"1988-03-28";FALSE;"de";0;"mc"
'1847027',-- ";"Marcos Luiz de Paula Bueno";"2011-02-11";"1984-01-29";FALSE;"de";0;"mc"
'1843825',-- ";"Victor Sobreira";"2011-02-08";"1981-02-23";FALSE;"de";0;"mc"
'1856628');--";"Thiago Pirola Ribeiro";"2012-11-09";"1978-09-30";FALSE;"de";0;"mc"

*/

-- alterando o status dessas disciplinas já distribuídas
UPDATE fila_turma
SET status = 8
WHERE id_turma IN (SELECT id_turma FROM ministra);

--- PROFESSORES CONSELHEREIROS 2017-01
delete from restricoes;
INSERT INTO restricoes
SELECT * FROM
(
SELECT siape FROM professor WHERE cnome = 'Ilmerio' -- Ilmério Reis da Silva – Diretor da FACOM – (Port. R nº757/11) 22/06/11 – 21/06/2015
UNION SELECT siape FROM professor WHERE cnome = 'Andre' --André Ricardo Backes - Coord. Núcleo Pesquisa - 26/05/15 - 25/05/17
UNION SELECT siape FROM professor WHERE cnome = 'Bruno' --Bruno Augusto Nassif Travençolo – Eleito 26/05/15 – 25/05/17
UNION SELECT siape FROM professor WHERE cnome = 'Fabiano' --Fabiano Azevedo Dorça – Coord BCC UNION Port. R nº1188/14) 11/01/15 - 10/01/17
UNION SELECT siape FROM professor WHERE cnome = 'Kil' --Kil Jin Brandini Park – Coord. BSI MC UNION Port. R nº 239/15) de 01/03/15 – 28/02/17
UNION SELECT siape FROM professor WHERE cnome = 'Faina' --Luis Fernando Faina – Eleito 01/05/15 a 30/04/17
UNION SELECT siape FROM professor WHERE cnome = 'Keese' --Marcelo Keese Albertini - Coord. Núcleo Extensão - 26/05/15 - 26/05/17
UNION SELECT siape FROM professor WHERE cnome = 'Zanchetta' --Marcelo Zanchetta do Nascimento - Eleito 01/08/15 a 31/07/17
UNION SELECT siape FROM professor WHERE cnome = 'Camila' --Maria Camila Nardini Barioni - Coord. PPGCO UNION Port. R nº /15) 13/06/15 - 12/06/17
UNION SELECT siape FROM professor WHERE cnome = 'Mauricio' --Maurício Cunha Escarpinati - Eleito 28/10/15 - 27/10/17
UNION SELECT siape FROM professor WHERE cnome = 'Renan' --Renan Gonçalves Cattelan - Eleito 11/01/15 - 10/01/17
UNION SELECT siape FROM professor WHERE cnome = 'Rodrigo' --Rodrigo Sanches Miani - Eleito 28/10/15 - 27/10/17
UNION SELECT siape FROM professor WHERE cnome = 'Stephane' --Stephane Julia – Eleito 26/05/15 – 25/05/17
UNION SELECT siape FROM professor WHERE cnome = 'Flavio'
UNION SELECT siape FROM professor WHERE cnome = 'Humberto' 
UNION SELECT siape FROM professor WHERE cnome = 'Ana' 
) AS P, (
      SELECT *
      FROM (SELECT '5') AS D, 
        (SELECT 'g' UNION 
         SELECT 'h' UNION 
         SELECT 'i' 
		 --UNION 
         --SELECT 'j'
		 --UNION 
         --SELECT 'k'
		 ) AS H) AS DH;
-- andressa unitri

insert into restricoes values ('2297167',2,'l'),('2297167',2,'m'),('2297167',2,'n'),('2297167',2,'o'),('2297167',2,'p');
insert into restricoes values ('2297167',3,'l'),('2297167',3,'m'),('2297167',3,'n'),('2297167',3,'o'),('2297167',3,'p');
insert into restricoes values ('2297167',4,'l'),('2297167',4,'m'),('2297167',4,'n'),('2297167',4,'o'),('2297167',4,'p');



-- tirando os afastados da distribuição
UPDATE fila_turma
SET status = 10
WHERE SIAPE IN (SELECT SIAPE FROM professor WHERE afastado = true);


END;
$$;

alter function atribui_optativas_ppgco() owner to postgres;

