create function ajustes_finais_2016_2_cenario1() returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 


-- ('TRANSF  ', 'Novo Professor Transferido 2016', None, 8)
-- (318, 'GSI023       ', 'S ', 'Redes de Computadores')
-- (334, 'FACOM49050   ', 'V ', 'Arquitetura e Organização de Computadores I')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('TRANSF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI023' AND ANO = 2016 AND SEMESTRE = 2)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('TRANSF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM49050' AND ANO = 2016 AND SEMESTRE = 2 ));

-- ('NOVOPROF', 'Novo Professor Concurso 2016', None, 8)
-- (291, 'GBC064       ', 'C ', 'Engenharia de Software')
-- (316, 'GSI020       ', 'S ', 'Programação Orientada a Objetos 2'
INSERT INTO MINISTRA(siape,id_turma) VALUES ('NOVOPROF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC064' AND ANO = 2016 AND SEMESTRE = 2)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('NOVOPROF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI020' AND ANO = 2016 AND SEMESTRE = 2 ));

-- ('2304166 ', 'Jean Roberto Ponciano', 2, 12)
--(329, 'GBC072       ', 'C ', 'Projeto de Graduação 1 + GBC082 Projeto de Graduação 2')
--(398, 'GSI005       ', 'V ', 'Lógica para Computação')
-- icc
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2304166',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC072' AND ANO = 2016 AND SEMESTRE = 2 ));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2304166',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI005' AND ANO = 2016 AND SEMESTRE = 2 AND TURMA = 'V'));

-- ('2143773 ', 'Renato Aparecido Pimentel da Silva', 6, 10)
-- (310, 'GSI009       ', 'S ', 'Profissão em Sistemas de Informação')
--(394, 'FACOM31701   ', 'S ', 'Trabalho de Conclusão de Curso 1 + FACOM31802 TCC2')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2143773',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI009' AND ANO = 2016 AND SEMESTRE = 2 ));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2143773',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM31701' AND ANO = 2016 AND SEMESTRE = 2 ));


--update fila
--set qte_maximo = 6, qte_ministrada = 0
--where siape = '2297590' and codigo_disc = 'GSI005' and ano = 2016 and semestre = 1;

-- Monte Carmelo
--('1843992 ', 'Ana Cláudia Martinez', 4, 8)
--('2302037 ', 'Italo Valença Mariotti Tasso', 8, 12)
--(363, 'GSI521       ', 'S ', 'MC -Organização e Recuperação da Informação')
--(364, 'GSI522       ', 'S ', 'MC -Modelagem de Software')



END;
$$;

alter function ajustes_finais_2016_2_cenario1() owner to postgres;

