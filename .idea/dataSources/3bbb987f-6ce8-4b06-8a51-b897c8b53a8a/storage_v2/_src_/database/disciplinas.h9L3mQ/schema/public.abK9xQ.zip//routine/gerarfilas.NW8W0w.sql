create function gerarfilas(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
     semestre_ant integer;
     ano_ant integer;
     
BEGIN 

  RAISE EXCEPTION 'NAO UTILIZAR.. EXISTE UM CÓDIGO PYTHON QUE FAZ ISSO';

  -- apagando as filas do semestre usado como parâmetro
  delete from fila where ano = t_ano and semestre = t_semestre;

  -- Resetando os ids para não crescer muito
  PERFORM setval('fila_id_seq', (select max(id)+1 from fila), false) ;

  IF (t_semestre = 1)
  THEN
    semestre_ant = 2; ano_ant = t_ano-1;
  ELSE
    semestre_ant = 1; ano_ant = t_ano;
  END IF;

  
  RAISE WARNING 'ano: % -> %, semestre : % -> %', ano_ant, t_ano, semestre_ant, t_semestre;


  -- copia a fila do semestre anterior
  INSERT INTO fila
     SELECT siape, codigo_disc, pos, prioridade,qte_ministrada,qte_maximo, t_ano, t_semestre
     FROM fila
     WHERE ano = ano_ant and semestre = semestre_ant;
 

   -- rodando as filas 	DO SEMESTRE ANTERIOR (tb foram rodadas no algortimo)
   -- possível bug no docente voluntário, que se mantém no no topo - solução seria aumentar qte_maximo
   create temporary table ff ON COMMIT DROP AS
                            SELECT f.id,f.codigo_disc,f.ano,f.semestre,p.siape,p.nome as pnome FROM fila f
                            inner join professor p on p.siape = f.siape
                            where  qte_ministrada >= qte_maximo and ano = ano_ant and semestre = semestre_ant
                            order by pos;

  -- dados já copiados, agora vão ser alterados
  FOR tupla in SELECT * FROM ff
  LOOP
      UPDATE fila f
      SET qte_ministrada = 0
      WHERE f.codigo_disc = tupla.codigo_disc and f.siape = tupla.siape and f.ano = t_ano and f.semestre = t_semestre;

      PERFORM rotacionar_fila(1,tupla.codigo_disc, t_ano, t_semestre);

      RAISE WARNING 'FILA RODADA: %, PROFESSOR: %', tupla.codigo_disc, tupla.pnome;
  END LOOP;




  -- alterando as posições de acordo com o ministra
  -- se houver mais de uma turma, a ordem é dada pelo artigo 22 parágrafo 1
  -- docente mais antigo primeiro (ou seja, vou mudar a posição do mais novo primeiro
  -- para depois do mais antigo
  
--alterar_posicao(t_siape character,t_codigo_disc character,t_ano integer,t_semestre integer,t_nova_pos integer)  

   create temporary table ff2 ON COMMIT DROP AS
                select f.siape, f.codigo_disc,p.nome as pnome, qte_ministrada
		from ministra m
		inner join turma t on t.id = m.id_turma
		inner join professor p on p.siape = m.siape
		inner join fila f on (f.siape = m.siape and f.codigo_disc = t.codigo_disc)
		where t.ano = ano_ant and t.semestre = semestre_ant and
		      f.ano = ano_ant and f.semestre = semestre_ant
		      order by data_ingresso desc;


  for tupla in select * from ff2
  LOOP
        -- jogando o professor para a primeira posição da fila
	PERFORM alterar_posicao(tupla.siape, tupla.codigo_disc, t_ano, t_semestre,1);

        -- alterando a quantidade de vezes em que foi ministrada a disciplina
	update fila
	set qte_ministrada = qte_ministrada + 1
	where fila.codigo_disc = tupla.codigo_disc and siape = tupla.siape and ano = t_ano and semestre = t_semestre;
        RAISE WARNING 'FILA alterada: %, PROFESSOR: %, qte % -> %', tupla.codigo_disc, tupla.pnome, tupla.qte_ministrada, tupla.qte_ministrada+1;	
  END LOOP;



   
END;
$$;

alter function gerarfilas(integer, integer) owner to postgres;

