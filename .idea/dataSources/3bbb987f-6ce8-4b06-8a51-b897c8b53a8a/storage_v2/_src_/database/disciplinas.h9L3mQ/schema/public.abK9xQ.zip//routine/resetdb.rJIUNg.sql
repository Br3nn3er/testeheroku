create function resetdb(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 
-- apagando as disciplinas atribuidas pelo sistema (que possuem fila)
delete from ministra
using turma, disciplina
where turma.id = ministra.id_turma and disciplina.codigo = turma.codigo_disc and 
     turma.ano = t_ano and turma.semestre = t_semestre and temfila =true;

--drop table fila_turma;

--create table fila_turma as
--SELECT siape, t.id as id_turma, f.codigo_disc, turma, pos, prioridade, qte_ministrada, qte_maximo, -1 as status, ch
--FROM fila f INNER JOIN turma t ON t.codigo_disc = f.codigo_disc
--WHERE t.ano = t_ano AND t.semestre = t_semestre and
--      f.ano = t_ano AND f.semestre = t_semestre AND
--       siape not in (select siape from professor where afastado=true);


--alter table fila_turma add id serial primary key;
delete from fila_turma;

insert into fila_turma(siape,id_turma,codigo_disc,turma,pos,prioridade,qte_ministrada,qte_maximo,status,ch,periodo_preferencial)
 select fila.siape,turma.id,turma.codigo_disc,turma.turma,fila.pos,fila_turma_new.prioridade,fila.qte_ministrada, fila.qte_maximo,-1,turma.ch,fila.periodo_preferencial
 from fila_turma_new
 inner join turma on turma.id = fila_turma_new.id_turma
 inner join fila on fila.id = fila_turma_new.id_fila
 where fila.ano = t_ano and fila.semestre = t_semestre;
  

UPDATE fila_turma
SET status = -1;

-- tirando os afastados da distribuição
UPDATE fila_turma
SET status = 10
WHERE SIAPE IN (SELECT SIAPE FROM professor WHERE afastado = true);



-- alterando o status dessas disciplinas já distribuídas
UPDATE fila_turma
SET status = 8
WHERE id_turma IN (SELECT id_turma FROM ministra);


--perform reorganiza_prioridades(t_ano,t_semestre);
-- perform atribui_optativas_ppgco();

 
   
END;
$$;

alter function resetdb(integer, integer) owner to postgres;

