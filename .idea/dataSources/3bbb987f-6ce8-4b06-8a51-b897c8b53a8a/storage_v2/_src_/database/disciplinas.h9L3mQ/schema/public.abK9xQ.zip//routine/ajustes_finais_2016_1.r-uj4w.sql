create function ajustes_finais_2016_1() returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 

---- 2016 01 -----


-- DINO
DELETE FROM MINISTRA
WHERE SIAPE = '2297590' AND id_turma = (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GET002' AND ANO = 2016 AND SEMESTRE = 1);
DELETE FROM MINISTRA
WHERE SIAPE = '2297590' AND id_turma = (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GAG009' AND ANO = 2016 AND SEMESTRE = 1);






-- LUIZ CLÁUDIO

DELETE FROM MINISTRA
WHERE SIAPE = '4035265' AND id_turma = (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GES005' AND ANO = 2016 AND SEMESTRE = 1);

-- LUIZ CLÁUDIO

INSERT INTO MINISTRA(siape,id_turma) VALUES ('4035265', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI009' AND ANO = 2016 AND SEMESTRE = 1)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('4035265', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBT017' AND ANO = 2016 AND SEMESTRE = 1)); 
update fila
set qte_maximo = 6, qte_ministrada = 0
where siape = '4035265' and codigo_disc = 'GSI009' and ano = 2016 and semestre = 1;

update fila
set qte_maximo = 6, qte_ministrada = 0
where siape = '4035265' and codigo_disc = 'GBT017' and ano = 2016 and semestre = 1;


-- LUCAS CUNHA
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2222796', (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GAG009' AND ANO = 2016 AND SEMESTRE = 1)); 

update fila
set qte_maximo = 6, qte_ministrada = 0
where siape = '2222796' and codigo_disc = 'GAG009' and ano = 2016 and semestre = 1;


-- DINO

INSERT INTO MINISTRA(siape,id_turma) VALUES ('2297590',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI005' AND ANO = 2016 AND SEMESTRE = 1)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2297590',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI019' AND ANO = 2016 AND SEMESTRE = 1 ));

update fila
set qte_maximo = 6, qte_ministrada = 0
where siape = '2297590' and codigo_disc = 'GSI005' and ano = 2016 and semestre = 1;

update fila
set qte_maximo = 6, qte_ministrada = 0
where siape = '2297590' and codigo_disc = 'GSI019' and ano = 2016 and semestre = 1;



-- SUBSTITUTO
INSERT INTO MINISTRA(siape,id_turma) VALUES ('subudi1',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GES005' AND ANO = 2016 AND SEMESTRE = 1));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('subudi1',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GET002' AND ANO = 2016 AND SEMESTRE = 1));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('subudi1',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI008' AND TURMA = 'V' AND ANO = 2016 AND SEMESTRE = 1 ));  
INSERT INTO MINISTRA(siape,id_turma) VALUES ('subudi1',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM49010(U)' AND ANO = 2016 AND SEMESTRE = 1 ));  


-- Monte Carmelo

-- Eduardo -- ', 'S ', 'MC -Projeto e Desenvolvimento de Sistemas de Informação 2')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2223490',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI538' AND ANO = 2016 AND SEMESTRE = 1)); 

-- Franciny -- ' , 'S ', 'MC -Banco de Dados 2')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2223661',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI523' AND ANO = 2016 AND SEMESTRE = 1)); 

-- KIl
INSERT INTO MINISTRA(siape,id_turma) VALUES ('1933801',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI519' AND ANO = 2016 AND SEMESTRE = 1));  -- ', 'S ', 'MC -Sistemas Operacionais')


-- novo substituto
INSERT INTO MINISTRA(siape,id_turma) VALUES ('submc2',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM33402' AND ANO = 2016 AND SEMESTRE = 1));  -- ', 'S ', 'MC -Programação para Dispositivos Móveis')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('submc2',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI516' AND ANO = 2016 AND SEMESTRE = 1));  -- ', 'S ', 'MC -Programação Orientada a Objetos 2')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('submc2',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GAC045' AND ANO = 2016 AND SEMESTRE = 1));  -- ', 'S ', 'MC -Programação para a Internet')


END;
$$;

alter function ajustes_finais_2016_1() owner to postgres;

