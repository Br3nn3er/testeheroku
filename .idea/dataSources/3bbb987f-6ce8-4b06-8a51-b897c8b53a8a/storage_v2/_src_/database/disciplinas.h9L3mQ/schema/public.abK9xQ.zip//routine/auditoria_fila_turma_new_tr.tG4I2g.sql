create function auditoria_fila_turma_new_tr() returns trigger
    language plpgsql
as
$$
BEGIN

        if (OLD.prioridade <> NEW.prioridade) 
        THEN
            INSERT INTO auditoria_fila_turma_new SELECT now(), NEW.id_turma, NEW.id_fila, OLD.prioridade, NEW.prioridade;
        END IF   ;
          
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;

alter function auditoria_fila_turma_new_tr() owner to postgres;

