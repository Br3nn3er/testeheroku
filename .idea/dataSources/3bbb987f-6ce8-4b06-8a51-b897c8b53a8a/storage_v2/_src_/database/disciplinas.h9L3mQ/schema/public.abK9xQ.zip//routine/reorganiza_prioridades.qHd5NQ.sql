create function reorganiza_prioridades(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 
-- bug: não está ordenando por turma, só prioridade
  FOR tupla IN SELECT siape FROM professor WHERE afastado = 'f'
  LOOP
    update fila_turma
    set prioridade = subquery.Sort_order
    from (select fila_turma.id, row_number() OVER (ORDER BY fila_turma.prioridade,fila_turma.turma) as Sort_order
          from fila_turma inner join turma on id_turma = turma.id
           where siape = '1770125' and ano = t_ano and semestre = t_semestre
 ) subquery
    where fila_turma.id = subquery.id;
  END LOOP;
   
END;
$$;

alter function reorganiza_prioridades(integer, integer) owner to postgres;

