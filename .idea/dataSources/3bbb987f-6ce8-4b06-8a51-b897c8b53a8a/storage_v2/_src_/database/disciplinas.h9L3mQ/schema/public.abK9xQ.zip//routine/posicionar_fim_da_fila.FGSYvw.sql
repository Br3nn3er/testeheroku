create function posicionar_fim_da_fila(t_siape character, t_codigo_disc character, t_ano integer, t_semestre integer, t_qte_ministrada integer, t_qte_maximo integer) returns void
    language plpgsql
as
$$
DECLARE
     pos_antiga integer;
     pos_final integer;
     tupla record;
BEGIN 
  
  SELECT max(pos)+1 INTO pos_final
  from  fila
  where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc ;

  UPDATE fila
  set pos = pos_final, qte_ministrada = t_qte_ministrada, qte_maximo = t_qte_maximo
  where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc and siape = t_siape; 

  PERFORM reorganizar_fila(t_codigo_disc, t_ano, t_semestre);

   
END;
$$;

alter function posicionar_fim_da_fila(char, char, integer, integer, integer, integer) owner to postgres;

