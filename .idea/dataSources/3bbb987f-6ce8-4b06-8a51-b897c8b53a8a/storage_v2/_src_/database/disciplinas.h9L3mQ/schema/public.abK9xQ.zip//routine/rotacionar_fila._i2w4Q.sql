create function rotacionar_fila(val integer, t_codigo_disc character, t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
     ntuplas integer;
BEGIN 

-- INSERT INTO auditoria_fila_antes2018(codigo_disc,stamp) VALUES ("ROT1_fila",now());

  PERFORM reorganizar_fila(t_codigo_disc, t_ano, t_semestre);
  
  SELECT COUNT(*) INTO ntuplas
  FROM FILA
  WHERE  ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc;
   
ALTER TABLE fila
  DROP CONSTRAINT fila_codigo_disc_pos_ano_semestre_key ;
  
  if (val>0)
  THEN
    UPDATE fila
    SET pos = pos-1
    WHERE ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc;

    UPDATE fila
    SET pos = ntuplas
    WHERE ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc and pos=0;
  ELSE
    UPDATE fila
    SET pos = pos+1
    WHERE ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc;

    UPDATE fila
    SET pos = 1
    WHERE ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc and pos=(ntuplas+1);
  END IF;  
  
ALTER TABLE fila
  ADD CONSTRAINT fila_codigo_disc_pos_ano_semestre_key UNIQUE(codigo_disc, pos, ano, semestre);

   
END;
$$;

alter function rotacionar_fila(integer, char, integer, integer) owner to postgres;

