create function resetdb_2016_1(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 

delete from ministra
using turma
where turma.id = ministra.id_turma and turma.ano = t_ano and turma.semestre = t_semestre;



--drop table fila_turma;

--create table fila_turma as
--SELECT siape, t.id as id_turma, f.codigo_disc, turma, pos, prioridade, qte_ministrada, qte_maximo, -1 as status, ch
--FROM fila f INNER JOIN turma t ON t.codigo_disc = f.codigo_disc
--WHERE t.ano = t_ano AND t.semestre = t_semestre and
--      f.ano = t_ano AND f.semestre = t_semestre AND
--       siape not in (select siape from professor where afastado=true);


--alter table fila_turma add id serial primary key;
delete from fila_turma;

insert into fila_turma select * from fila_turma_2016_1;

UPDATE fila_turma
SET status = -1;



perform reorganiza_prioridades();
perform atribui_optativas_ppgco();

 
   
END;
$$;

alter function resetdb_2016_1(integer, integer) owner to postgres;

