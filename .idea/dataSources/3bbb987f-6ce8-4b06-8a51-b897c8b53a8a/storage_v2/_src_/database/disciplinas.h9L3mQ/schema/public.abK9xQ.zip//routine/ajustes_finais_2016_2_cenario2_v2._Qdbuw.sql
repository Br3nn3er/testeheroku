create function ajustes_finais_2016_2_cenario2_v2() returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 


-- "Novo Professor Transferido 2016";"FACOM49050   ";"V ";"Arquitetura e Organização de Computadores I";"Engenharia Mecatrônica";4;"";"2c,2d,3c,3d"
-- "Novo Professor Transferido 2016";"GSI023       ";"S ";"Redes de Computadores";"Sistemas de Informação";4;"";"2m,2n,4o,4p"

-- ('TRANSF  ', 'Novo Professor Transferido 2016', None, 8)
-- (318, 'GSI023       ', 'S ', 'Redes de Computadores')
-- (334, 'FACOM49050   ', 'V ', 'Arquitetura e Organização de Computadores I')
INSERT INTO MINISTRA(siape,id_turma) VALUES ('TRANSF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI023' AND ANO = 2016 AND SEMESTRE = 2)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('TRANSF  ',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM49050' AND ANO = 2016 AND SEMESTRE = 2 ));

-- ('2297167 ', 'Andrêssa Finzi de Abreu', 12, 16)
-- passando mecatronica para jean
-- (329, 'GBC072       ', 'C ', 'Projeto de Graduação 1 + GBC082 Projeto de Graduação 2')
-- Pega ICC di Jean
delete from ministra where siape = '2297167' and id_turma = (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM49010(U)' AND ANO = 2016 AND SEMESTRE = 2 );
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2297167',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC072' AND ANO = 2016 AND SEMESTRE = 2)); 
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2297167',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC015' AND ANO = 2016 AND SEMESTRE = 2)); 

-- ('2304166 ', 'Jean Roberto Ponciano', 2, 12)
-- TIRA ICC
-- mecatronica
-- (291, 'GBC064       ', 'C ', 'Engenharia de Software')
-- (398, 'GSI005       ', 'V ', 'Lógica para Computação')
delete from ministra where siape = '2304166' and id_turma = (SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC015' AND ANO = 2016 AND SEMESTRE = 2 );
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2304166',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM49010(U)' AND ANO = 2016 AND SEMESTRE = 2 ));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2304166',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GBC064' AND ANO = 2016 AND SEMESTRE = 2 ));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2304166',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI005' AND ANO = 2016 AND SEMESTRE = 2  AND turma = 'V' ));

-- ('2143773 ', 'Renato Aparecido Pimentel da Silva', 6, 10)
-- (310, 'GSI009       ', 'S ', 'Profissão em Sistemas de Informação')
--(394, 'FACOM31701   ', 'S ', 'Trabalho de Conclusão de Curso 1 + FACOM31802 TCC2')
--INSERT INTO MINISTRA(siape,id_turma) VALUES ('2143773',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'GSI009' AND ANO = 2016 AND SEMESTRE = 2 ));
INSERT INTO MINISTRA(siape,id_turma) VALUES ('2143773',(SELECT ID FROM TURMA WHERE CODIGO_DISC = 'FACOM31701' AND ANO = 2016 AND SEMESTRE = 2 ));

--update fila
--set qte_maximo = 6, qte_ministrada = 0
--where siape = '2297590' and codigo_disc = 'GSI005' and ano = 2016 and semestre = 1;

-- Monte Carmelo
--('1843992 ', 'Ana Cláudia Martinez', 4, 8)
--('2302037 ', 'Italo Valença Mariotti Tasso', 8, 12)
--(363, 'GSI521       ', 'S ', 'MC -Organização e Recuperação da Informação')
--(364, 'GSI522       ', 'S ', 'MC -Modelagem de Software')



END;
$$;

alter function ajustes_finais_2016_2_cenario2_v2() owner to postgres;

