create function alterar_posicao(t_siape character, t_codigo_disc character, t_ano integer, t_semestre integer, t_nova_pos integer, t_qte_ministrada integer, t_qte_maximo integer) returns void
    language plpgsql
as
$$
DECLARE
     pos_antiga integer;
     tupla record;
BEGIN 

  PERFORM reorganizar_fila(t_codigo_disc, t_ano, t_semestre);

ALTER TABLE fila
  DROP CONSTRAINT fila_codigo_disc_pos_ano_semestre_key ;

    SELECT pos INTO pos_antiga
    from  fila
    where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc and siape = t_siape;

    if (pos_antiga> T_nova_pos)
    THEN
      UPDATE fila
      set pos = pos+1
      where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc 
        and pos >=t_nova_pos and pos < pos_antiga;
     ELSE
      UPDATE fila
      set pos = pos-1
      where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc 
        and pos <=t_nova_pos and pos > pos_antiga;
     END IF;
    

    UPDATE fila
    set pos = t_nova_pos, qte_ministrada = t_qte_ministrada, qte_maximo = t_qte_maximo
    where ano = t_ano and semestre = t_semestre and codigo_disc = t_codigo_disc and siape = t_siape;
  
ALTER TABLE fila
  ADD CONSTRAINT fila_codigo_disc_pos_ano_semestre_key UNIQUE(codigo_disc, pos, ano, semestre);

  RAISE notice 'Fila alterada %' , t_codigo_disc;
   
END;
$$;

alter function alterar_posicao(char, char, integer, integer, integer, integer, integer) owner to postgres;

