create function reorganizar_todas_as_filas(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 

  FOR tupla IN SELECT codigo FROM disciplina
  LOOP
    perform reorganizar_fila(tupla.codigo, t_ano, t_semestre );
  END LOOP;
  
   
END;
$$;

alter function reorganizar_todas_as_filas(integer, integer) owner to postgres;

