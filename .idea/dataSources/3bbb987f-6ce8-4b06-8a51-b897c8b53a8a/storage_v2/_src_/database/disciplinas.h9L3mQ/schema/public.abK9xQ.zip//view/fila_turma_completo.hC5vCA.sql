create view fila_turma_completo(id_turma, id_fila, prioridade, codigo_disc, turma, siape, pos) as
SELECT ft.id_turma,
       ft.id_fila,
       ft.prioridade,
       t.codigo_disc,
       t.turma,
       f.siape,
       f.pos
FROM fila_turma_new ft
         JOIN turma t ON t.id = ft.id_turma
         JOIN fila f ON f.id = ft.id_fila
WHERE ((f.ano, f.semestre) IN (SELECT semestres.ano,
                                      semestres.semestre
                               FROM semestres
                               WHERE semestres.status = true));

alter table fila_turma_completo
    owner to postgres;

