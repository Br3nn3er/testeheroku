create function set_semestre(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     
BEGIN 
 UPDATE semestres
 SET status = false;

 UPDATE semestres
 SET status = true
 where ano = t_ano and semestre = t_semestre;
 
   
END;
$$;

alter function set_semestre(integer, integer) owner to postgres;

