create view docentes_view(siape, data_ingresso, nome, regime, lotacao) as
SELECT professor.siape,
       professor.data_ingresso,
       professor.nome,
       CASE professor.regime
           WHEN '20h'::text THEN '20 Horas'::text
           WHEN '40h'::text THEN '40 Horas'::text
           WHEN 'sub'::text THEN 'Temporário'::text
           ELSE 'DE'::text
           END           AS regime,
       professor.locacao AS lotacao
FROM professor
WHERE professor.afastado = false;

alter table docentes_view
    owner to postgres;

