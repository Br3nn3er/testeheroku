create function reorganiza_prioridades_filas(t_ano integer, t_semestre integer) returns void
    language plpgsql
as
$$
DECLARE
     tupla record;
BEGIN 
-- bug: não está ordenando por turma, só prioridade
  FOR tupla IN SELECT siape FROM professor 
  LOOP
    update fila
    set prioridade = subquery.Sort_order
    from (select id, prioridade,row_number() OVER (ORDER BY prioridade) as Sort_order
          from fila
           where siape = tupla.siape
           and ano = t_ano and semestre = t_semestre
          ) subquery
    where fila.id = subquery.id;
  END LOOP;
   
END;
$$;

alter function reorganiza_prioridades_filas(integer, integer) owner to postgres;

